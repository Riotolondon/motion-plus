import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Camera, Award, Clock, Heart } from 'lucide-react';
import Hero from '../components/Hero';

const AboutPage: React.FC = () => {
  useEffect(() => {
    document.title = 'About Us | MOTION+ Photography';
  }, []);

  const features = [
    {
      icon: <Camera className="h-8 w-8 text-brand-blue" />,
      title: 'Professional Equipment',
      description: 'We use top-of-the-line cameras, lenses, and lighting equipment to deliver exceptional quality images.'
    },
    {
      icon: <Award className="h-8 w-8 text-brand-blue" />,
      title: 'Experienced Team',
      description: 'Our photographers bring years of experience and artistic vision to every photography session.'
    },
    {
      icon: <Clock className="h-8 w-8 text-brand-blue" />,
      title: 'Timely Delivery',
      description: 'We understand the importance of receiving your photos promptly and deliver edited images on schedule.'
    },
    {
      icon: <Heart className="h-8 w-8 text-brand-blue" />,
      title: 'Passion for Photography',
      description: 'We are passionate about photography and dedicated to capturing beautiful, meaningful images.'
    }
  ];

  return (
    <>
      <Hero 
        title="About MOTION+"
        subtitle="Professional photographers capturing life's precious moments"
        backgroundImage="https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-16 md:py-24 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Our <span className="text-brand-blue">Story</span>
              </h2>
              <p className="text-gray-300 mb-4">
                MOTION+ Photography was founded with a simple mission: to capture life's most precious moments with creativity, skill, and passion.
              </p>
              <p className="text-gray-300 mb-4">
                Our journey began when a group of photography enthusiasts came together, united by their love for the art and their desire to create meaningful visual stories for clients.
              </p>
              <p className="text-gray-300 mb-4">
                Today, we've grown into a respected photography studio offering a wide range of services, from wedding and event photography to corporate headshots and lifestyle sessions.
              </p>
              <p className="text-gray-300">
                Our motto, [don't Blink], reminds us and our clients to cherish every moment, as we're dedicated to preserving them forever through our lens.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.pexels.com/photos/3178744/pexels-photo-3178744.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Photographer at work" 
                className="rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-10 -left-10 bg-gray-900 p-6 rounded-lg shadow-lg max-w-[200px]">
                <p className="text-gray-300 italic text-sm">"Photography is the art of freezing time and preserving emotions forever."</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Our Approach */}
      <section className="py-16 md:py-24 bg-gray-950">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Approach</h2>
            <p className="text-gray-400 max-w-3xl mx-auto">
              We believe in creating authentic, timeless images that tell your unique story.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-900 p-6 rounded-lg text-center"
              >
                <div className="flex justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Team */}
      <section className="py-16 md:py-24 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-gray-400 max-w-3xl mx-auto">
              Our talented photographers bring a unique perspective and years of experience to every project.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-gray-900 rounded-lg overflow-hidden"
            >
              <img 
                src="https://images.pexels.com/photos/3760263/pexels-photo-3760263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Team member" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">David Williams</h3>
                <p className="text-brand-blue mb-4">Lead Photographer</p>
                <p className="text-gray-400">Specializing in wedding and portrait photography with over 10 years of experience capturing life's special moments.</p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-gray-900 rounded-lg overflow-hidden"
            >
              <img 
                src="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Team member" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">Sarah Johnson</h3>
                <p className="text-brand-blue mb-4">Corporate Specialist</p>
                <p className="text-gray-400">With a background in marketing, Sarah brings a unique perspective to corporate photography and personal branding.</p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true }}
              className="bg-gray-900 rounded-lg overflow-hidden"
            >
              <img 
                src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Team member" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">Michael Chen</h3>
                <p className="text-brand-blue mb-4">Lifestyle & Event Photographer</p>
                <p className="text-gray-400">A creative eye for capturing authentic moments, Michael specializes in lifestyle photography and event coverage.</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;