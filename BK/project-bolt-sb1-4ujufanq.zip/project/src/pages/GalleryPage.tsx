import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Hero from '../components/Hero';
import GalleryItem from '../components/GalleryItem';

const GalleryPage: React.FC = () => {
  const [filter, setFilter] = useState('all');
  
  useEffect(() => {
    document.title = 'Gallery | MOTION+ Photography';
  }, []);

  const galleryItems = [
    {
      id: 1,
      title: 'Elegant Wedding',
      category: 'wedding',
      image: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 2,
      title: 'Business Conference',
      category: 'corporate',
      image: 'https://images.pexels.com/photos/2182973/pexels-photo-2182973.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 3,
      title: 'Family Portrait',
      category: 'portrait',
      image: 'https://images.pexels.com/photos/1974521/pexels-photo-1974521.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 4,
      title: 'Couple Photoshoot',
      category: 'lifestyle',
      image: 'https://images.pexels.com/photos/1024970/pexels-photo-1024970.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 5,
      title: 'Corporate Headshot',
      category: 'corporate',
      image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 6,
      title: 'Beach Wedding',
      category: 'wedding',
      image: 'https://images.pexels.com/photos/1244690/pexels-photo-1244690.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 7,
      title: 'Maternity Session',
      category: 'portrait',
      image: 'https://images.pexels.com/photos/1682497/pexels-photo-1682497.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 8,
      title: 'Birthday Celebration',
      category: 'event',
      image: 'https://images.pexels.com/photos/2399097/pexels-photo-2399097.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 9,
      title: 'Personal Branding',
      category: 'lifestyle',
      image: 'https://images.pexels.com/photos/1587014/pexels-photo-1587014.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 10,
      title: 'Corporate Event',
      category: 'corporate',
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 11,
      title: 'Newborn Photography',
      category: 'portrait',
      image: 'https://images.pexels.com/photos/265987/pexels-photo-265987.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 12,
      title: 'Engagement Session',
      category: 'event',
      image: 'https://images.pexels.com/photos/1128318/pexels-photo-1128318.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
  ];

  const filteredItems = filter === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === filter);

  return (
    <>
      <Hero 
        title="Our Photography Portfolio"
        subtitle="Explore our work across various photography styles"
        backgroundImage="https://images.pexels.com/photos/167635/pexels-photo-167635.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-16 md:py-24 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Gallery</h2>
            <p className="text-gray-400 max-w-3xl mx-auto mb-8">
              Browse through our collection of professional photography across various categories.
            </p>
            
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              <button
                onClick={() => setFilter('all')}
                className={`px-6 py-2 rounded-full transition-all ${
                  filter === 'all' 
                    ? 'bg-brand-blue text-white' 
                    : 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilter('wedding')}
                className={`px-6 py-2 rounded-full transition-all ${
                  filter === 'wedding' 
                    ? 'bg-brand-blue text-white' 
                    : 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                }`}
              >
                Wedding
              </button>
              <button
                onClick={() => setFilter('corporate')}
                className={`px-6 py-2 rounded-full transition-all ${
                  filter === 'corporate' 
                    ? 'bg-brand-blue text-white' 
                    : 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                }`}
              >
                Corporate
              </button>
              <button
                onClick={() => setFilter('portrait')}
                className={`px-6 py-2 rounded-full transition-all ${
                  filter === 'portrait' 
                    ? 'bg-brand-blue text-white' 
                    : 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                }`}
              >
                Portrait
              </button>
              <button
                onClick={() => setFilter('event')}
                className={`px-6 py-2 rounded-full transition-all ${
                  filter === 'event' 
                    ? 'bg-brand-blue text-white' 
                    : 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                }`}
              >
                Event
              </button>
              <button
                onClick={() => setFilter('lifestyle')}
                className={`px-6 py-2 rounded-full transition-all ${
                  filter === 'lifestyle' 
                    ? 'bg-brand-blue text-white' 
                    : 'bg-gray-900 text-gray-300 hover:bg-gray-800'
                }`}
              >
                Lifestyle
              </button>
            </div>
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div 
              key={filter}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
            >
              {filteredItems.map(item => (
                <GalleryItem
                  key={item.id}
                  image={item.image}
                  title={item.title}
                  category={item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                />
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>
    </>
  );
};

export default GalleryPage;