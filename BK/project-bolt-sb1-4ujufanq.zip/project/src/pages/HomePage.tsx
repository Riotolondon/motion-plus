import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Camera, Users, Briefcase, Image } from 'lucide-react';
import Hero from '../components/Hero';
import ServiceCard from '../components/ServiceCard';
import TestimonialCard from '../components/TestimonialCard';

const HomePage: React.FC = () => {
  useEffect(() => {
    document.title = 'MOTION+ Photography | Professional Photography Services';
  }, []);

  const services = [
    {
      title: 'Event Photography',
      description: 'Capture the essence of your special events with our professional event photography services, including weddings, birthdays, and engagements.',
      icon: <Users className="h-5 w-5 text-white" />,
      image: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/services#event'
    },
    {
      title: 'Corporate Photography',
      description: 'Professional corporate photography for conferences, events, and executive headshots that strengthen your brand image.',
      icon: <Briefcase className="h-5 w-5 text-white" />,
      image: 'https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/services#corporate'
    },
    {
      title: 'Portrait Photography',
      description: 'Beautiful portrait photography for individuals, families, maternity, and newborns with a focus on natural expressions.',
      icon: <Camera className="h-5 w-5 text-white" />,
      image: 'https://images.pexels.com/photos/1586973/pexels-photo-1586973.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/services#portrait'
    },
    {
      title: 'Lifestyle Photography',
      description: 'Creative lifestyle photography for couples, personal branding, and storytelling that captures authentic moments.',
      icon: <Image className="h-5 w-5 text-white" />,
      image: 'https://images.pexels.com/photos/1580271/pexels-photo-1580271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      link: '/services#lifestyle'
    }
  ];

  const testimonials = [
    {
      quote: "MOTION+ Photography captured our wedding day beautifully. The photos exceeded our expectations, and the photographer was professional and unobtrusive.",
      author: "Sarah & Michael",
      role: "Wedding Clients"
    },
    {
      quote: "The corporate headshots for our team were excellent. Quick, professional service with great results that we're proud to use on our website.",
      author: "James Wilson",
      role: "Marketing Director"
    },
    {
      quote: "Our family portrait session was so much fun, and the photos are treasures we'll keep forever. Highly recommend MOTION+ for any photography needs.",
      author: "The Thompson Family",
      role: "Portrait Clients"
    }
  ];

  return (
    <>
      <Hero 
        title="Capturing Moments That Last Forever"
        subtitle="Professional photography services for all your special moments"
        buttonText="View Our Work"
        buttonLink="/gallery"
        backgroundImage="https://images.pexels.com/photos/1261824/pexels-photo-1261824.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />

      {/* About Section */}
      <section className="py-16 md:py-24 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.pexels.com/photos/3568520/pexels-photo-3568520.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Photographer with camera" 
                className="rounded-lg shadow-lg object-cover h-[500px] w-full"
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                About <span className="text-brand-blue">MOTION+</span>
              </h2>
              <p className="text-gray-300 mb-6">
                We are a team of passionate photographers dedicated to capturing the essence of your special moments. At MOTION+, we believe every picture tells a story, and we're committed to making sure your story is told with creativity, professionalism, and technical excellence.
              </p>
              <p className="text-gray-300 mb-8">
                With years of experience across various photography specialties, we bring a unique perspective to every shoot. Our motto [don't Blink] reminds us and our clients to cherish every moment, as we're dedicated to preserving them forever through our lens.
              </p>
              <Link
                to="/about"
                className="inline-block border-2 border-brand-blue text-brand-blue px-6 py-2 rounded-md font-medium hover:bg-brand-blue hover:text-white transition-colors duration-300"
              >
                Learn More About Us
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24 bg-gray-950">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-gray-400 max-w-3xl mx-auto">
              We offer a comprehensive range of professional photography services tailored to your specific needs.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Link to={service.link} key={index}>
                <ServiceCard 
                  title={service.title}
                  description={service.description}
                  icon={service.icon}
                  image={service.image}
                />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 md:py-24 bg-brand-blue">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Ready to Capture Your Special Moments?</h2>
          <p className="text-white text-opacity-90 max-w-3xl mx-auto mb-8">
            Let's work together to create stunning images that you'll cherish for a lifetime.
          </p>
          <Link
            to="/contact"
            className="inline-block bg-white text-brand-blue px-8 py-3 rounded-md font-medium text-lg hover:bg-gray-100 transition-colors duration-300"
          >
            Contact Us Today
          </Link>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-gray-400 max-w-3xl mx-auto">
              Read testimonials from our satisfied clients.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard
                key={index}
                quote={testimonial.quote}
                author={testimonial.author}
                role={testimonial.role}
              />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;