import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Hero from '../components/Hero';
import PricingTable from '../components/PricingTable';

const ServicesPage: React.FC = () => {
  const location = useLocation();
  
  useEffect(() => {
    document.title = 'Our Services | MOTION+ Photography';
    
    // Scroll to the section based on hash
    const hash = location.hash;
    if (hash) {
      const element = document.getElementById(hash.substring(1));
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 500);
      }
    }
  }, [location]);

  const eventPricing = [
    {
      title: 'Wedding Photography - Package A',
      description: '4 hours coverage',
      price: 'R6,000',
    },
    {
      title: 'Wedding Photography - Package B',
      description: '8 hours coverage + 100 edited photos',
      price: 'R12,000',
    },
    {
      title: 'Wedding Photography - Package C',
      description: 'Full day coverage + 200 edited photos',
      price: 'R18,000',
    },
    {
      title: 'Engagement Photoshoot',
      description: '1-hour session + 20 edited photos',
      price: 'R2,000',
    },
    {
      title: 'Birthday Party - Standard',
      description: '3 hours coverage + 50 edited photos',
      price: 'R3,500',
    },
    {
      title: 'Birthday Party - Premium',
      description: '6 hours coverage + 100 edited photos + photobook',
      price: 'R6,500',
    },
  ];

  const corporatePricing = [
    {
      title: 'Conference & Event - Half Day',
      description: '4 hours coverage',
      price: 'R4,500',
    },
    {
      title: 'Conference & Event - Full Day',
      description: '8 hours coverage',
      price: 'R8,500',
    },
    {
      title: 'Corporate Headshots (1-5 people)',
      description: 'Professional headshots with retouching',
      price: 'R1,000 per person',
    },
    {
      title: 'Corporate Headshots (6-10 people)',
      description: 'Professional headshots with retouching',
      price: 'R850 per person',
    },
    {
      title: 'Corporate Headshots (11+ people)',
      description: 'Professional headshots with retouching',
      price: 'R750 per person',
    },
  ];

  const portraitPricing = [
    {
      title: 'Family Portrait Session',
      description: '1-hour session + 30 edited photos',
      price: 'R2,500',
    },
    {
      title: 'Maternity Photoshoot',
      description: '2-hour session + 40 edited photos',
      price: 'R3,000',
    },
    {
      title: 'Newborn Photoshoot',
      description: '3-hour session + 50 edited photos',
      price: 'R4,500',
    },
  ];

  const lifestylePricing = [
    {
      title: 'Couple/Anniversary Photoshoot',
      description: '1-hour session + 25 edited photos',
      price: 'R2,200',
    },
    {
      title: 'Personal Branding Photography',
      description: '2-hour session + 50 edited photos',
      price: 'R3,500',
    },
  ];

  return (
    <>
      <Hero 
        title="Our Services & Pricing"
        subtitle="Professional photography packages tailored to your needs"
        backgroundImage="https://images.pexels.com/photos/3568517/pexels-photo-3568517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-16 md:py-24 bg-black">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Photography Services</h2>
            <p className="text-gray-400 max-w-3xl mx-auto">
              We offer a comprehensive range of professional photography services at competitive rates.
              All prices include professional editing and digital delivery of your photos.
            </p>
          </div>
          
          <div id="event" className="pt-16 -mt-16">
            <PricingTable category="Event" items={eventPricing} />
          </div>
          
          <div id="corporate" className="pt-16 -mt-16">
            <PricingTable category="Corporate" items={corporatePricing} />
          </div>
          
          <div id="portrait" className="pt-16 -mt-16">
            <PricingTable category="Portrait" items={portraitPricing} />
          </div>
          
          <div id="lifestyle" className="pt-16 -mt-16">
            <PricingTable category="Lifestyle" items={lifestylePricing} />
          </div>

          <div className="bg-gray-900 rounded-lg p-8 mt-12">
            <h3 className="text-2xl font-bold mb-4">Custom Packages</h3>
            <p className="text-gray-300 mb-4">
              Need something specific? We can create custom photography packages tailored to your unique requirements.
            </p>
            <p className="text-gray-300">
              Contact us to discuss your project and get a personalized quote.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;