import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, ExternalLink, Instagram, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 pt-12 pb-6">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <img src="/logo.png" alt="MOTION+" className="h-12" />
            </div>
            <p className="text-gray-400 mb-4">
              Professional photography services capturing your special moments with exceptional quality and creativity.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-blue transition-colors">
                <Instagram size={20} />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-brand-blue transition-colors">
                <Facebook size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-400 hover:text-white transition-colors">Services</Link>
              </li>
              <li>
                <Link to="/gallery" className="text-gray-400 hover:text-white transition-colors">Gallery</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/services#event" className="text-gray-400 hover:text-white transition-colors">Event Photography</Link>
              </li>
              <li>
                <Link to="/services#corporate" className="text-gray-400 hover:text-white transition-colors">Corporate Photography</Link>
              </li>
              <li>
                <Link to="/services#portrait" className="text-gray-400 hover:text-white transition-colors">Portrait Photography</Link>
              </li>
              <li>
                <Link to="/services#lifestyle" className="text-gray-400 hover:text-white transition-colors">Lifestyle Photography</Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-2">
                <Phone size={18} className="text-brand-blue" />
                <a href="tel:+27682408816" className="text-gray-400 hover:text-white transition-colors">+27 68 240 8816</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail size={18} className="text-brand-blue" />
                <a href="mailto:info@motionplus.com" className="text-gray-400 hover:text-white transition-colors">info@motionplus.com</a>
              </li>
              <li className="flex items-center gap-2">
                <ExternalLink size={18} className="text-brand-blue" />
                <a href="https://www.motionplus.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">www.motionplus.com</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-6 mt-6">
          <p className="text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} MOTION+ Photography. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;