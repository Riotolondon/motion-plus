import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface GalleryItemProps {
  image: string;
  title: string;
  category: string;
}

const GalleryItem: React.FC<GalleryItemProps> = ({ image, title, category }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div 
      className="overflow-hidden rounded-lg relative group"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <img 
        src={image} 
        alt={title} 
        className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
      />
      
      <div className={`absolute inset-0 bg-black bg-opacity-60 flex flex-col justify-end p-4 transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
        <div className="transform transition-transform duration-300 translate-y-4 group-hover:translate-y-0">
          <span className="text-brand-blue text-sm uppercase tracking-wider">{category}</span>
          <h3 className="text-white text-lg font-semibold">{title}</h3>
        </div>
      </div>
    </motion.div>
  );
};

export default GalleryItem;